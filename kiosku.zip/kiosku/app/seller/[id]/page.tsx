import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { cardSelect } from "@/lib/listings";
import { getFavoriteIds } from "@/lib/queries";
import { ListingCard } from "@/components/ListingCard";
import { EmptyState } from "@/components/EmptyState";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const u = await db.user.findUnique({ where: { id: (await params).id }, select: { name: true } });
  return { title: u ? `Profil ${u.name}` : "Penjual" };
}

export default async function SellerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const seller = await db.user.findUnique({
    where: { id },
    select: { id: true, name: true, role: true, verifiedStatus: true, createdAt: true, blocked: true },
  });
  if (!seller || seller.blocked || seller.role === "ADMIN") notFound();

  const [listings, rating, reviews, favs] = await Promise.all([
    db.listing.findMany({ where: { sellerId: id, status: "PUBLISHED" }, orderBy: { createdAt: "desc" }, take: 24, select: cardSelect }),
    db.review.aggregate({ where: { sellerId: id }, _avg: { rating: true }, _count: true }),
    db.review.findMany({ where: { sellerId: id }, orderBy: { createdAt: "desc" }, take: 5, include: { author: { select: { name: true } } } }),
    getFavoriteIds(),
  ]);

  return (
    <div className="container-x py-8">
      <div className="card mb-8 flex items-center gap-5 p-6">
        <div className="grid h-16 w-16 place-items-center rounded-full bg-brand-100 text-2xl font-bold text-brand">
          {seller.name.charAt(0).toUpperCase()}
        </div>
        <div>
          <h1 className="text-xl font-bold">{seller.name}</h1>
          {seller.verifiedStatus === "VERIFIED" && <p className="text-sm font-medium text-emerald-600">✓ Terverifikasi KIOSKU</p>}
          <p className="text-sm text-navy-500">
            Bergabung sejak {seller.createdAt.getFullYear()} · {listings.length} listing aktif · ⭐{" "}
            {rating._count > 0 ? `${(rating._avg.rating ?? 0).toFixed(1)} (${rating._count})` : "belum ada ulasan"}
          </p>
        </div>
      </div>
      <h2 className="mb-4 text-lg font-bold">Listing aktif</h2>
      {listings.length === 0 ? (
        <EmptyState title="Belum ada listing aktif" />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {listings.map((l) => <ListingCard key={l.id} l={l} favorited={favs.has(l.id)} />)}
        </div>
      )}
      {reviews.length > 0 && (
        <>
          <h2 className="mb-4 mt-10 text-lg font-bold">Ulasan</h2>
          <div className="space-y-3">
            {reviews.map((r) => (
              <div key={r.id} className="card p-4">
                <p className="font-semibold">{r.author.name} <span className="text-amber-500">{"★".repeat(r.rating)}</span></p>
                {r.comment && <p className="text-sm text-navy-500">{r.comment}</p>}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
