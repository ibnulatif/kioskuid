import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { reviewSchema } from "@/lib/validation";

/**
 * Review hanya valid jika listing sudah SOLD/RENTED dan pembeli pernah
 * melakukan percakapan dengan penjual untuk listing tersebut.
 */
export async function POST(req: Request) {
  try {
    const s = await requireRole();
    const data = reviewSchema.parse(await req.json());
    const listing = await db.listing.findUnique({
      where: { id: data.listingId },
      select: { id: true, sellerId: true, status: true },
    });
    if (!listing) throw new HttpError(404, "Listing tidak ditemukan.");
    if (listing.status !== "SOLD" && listing.status !== "RENTED") {
      throw new HttpError(422, "Review hanya dapat diberikan setelah transaksi selesai.");
    }
    if (listing.sellerId === s.id) throw new HttpError(422, "Tidak dapat mereview listing sendiri.");
    const talked = await db.conversation.findUnique({
      where: { listingId_buyerId: { listingId: listing.id, buyerId: s.id } },
    });
    if (!talked) throw new HttpError(403, "Hanya pembeli yang bertransaksi yang dapat memberi review.");
    const review = await db.review.upsert({
      where: { listingId_authorId: { listingId: listing.id, authorId: s.id } },
      update: { rating: data.rating, comment: data.comment },
      create: { listingId: listing.id, authorId: s.id, sellerId: listing.sellerId, rating: data.rating, comment: data.comment },
    });
    return ok(review, 201);
  } catch (e) {
    return fail(e);
  }
}
