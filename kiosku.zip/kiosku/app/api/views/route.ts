import { db } from "@/lib/db";
import { ok, fail, clientIp } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";

/** Menambah hitungan dilihat; dipanggil klien sekali per kunjungan. */
export async function POST(req: Request) {
  try {
    const { listingId } = (await req.json()) as { listingId?: string };
    if (!listingId) return ok({ ok: false }, 422);
    rateLimit(`view:${clientIp(req)}:${listingId}`, 3, 10 * 60_000);
    await db.listing.updateMany({ where: { id: listingId, status: "PUBLISHED" }, data: { views: { increment: 1 } } });
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
