import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate } from "@/lib/utils";
import { UserActions } from "@/components/AdminActions";

export const metadata = { title: "Pengguna" };
export const dynamic = "force-dynamic";

export default async function AdminUsers() {
  const admin = await requireRole("ADMIN");
  const users = await db.user.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { _count: { select: { listings: true } } },
  });
  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">Pengguna</h1>
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[700px] text-left text-sm">
          <thead className="border-b border-navy-100 text-xs uppercase text-navy-500">
            <tr>{["Nama", "Email", "Role", "Verifikasi", "Listing", "Bergabung", ""].map((h) => <th key={h} className="p-3">{h}</th>)}</tr>
          </thead>
          <tbody className="divide-y divide-navy-100">
            {users.map((u) => (
              <tr key={u.id}>
                <td className="p-3 font-medium">{u.name}{u.blocked && <span className="badge ml-2 bg-red-100 text-red-700">Diblokir</span>}</td>
                <td className="p-3">{u.email}</td>
                <td className="p-3">{u.role}</td>
                <td className="p-3">{u.verifiedStatus}</td>
                <td className="p-3">{u._count.listings}</td>
                <td className="p-3">{formatDate(u.createdAt)}</td>
                <td className="p-3">{u.id !== admin.id && <UserActions id={u.id} blocked={u.blocked} />}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
