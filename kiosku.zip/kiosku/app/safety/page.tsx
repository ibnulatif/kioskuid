import { StaticPage } from "@/components/StaticPage";

export const metadata = { title: "Keamanan" };

export default function Page() {
  return (
    <StaticPage title="Tips Keamanan KIOSKU">
      <p>Jangan melakukan pembayaran sebelum memeriksa lokasi, dokumen, dan identitas penjual.</p>
      <h2>Sebelum bertransaksi</h2>
      <p>Kunjungi lokasi secara langsung, periksa sertifikat atau surat sewa, dan pastikan nama pemilik sesuai identitas.</p>
      <h2>Lihat sesuatu yang mencurigakan?</h2>
      <p>Gunakan tombol “Laporkan Listing” pada halaman detail. Tim kami akan meninjau laporan Anda.</p>
    </StaticPage>
  );
}
