import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { audit } from "@/lib/notify";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const admin = await requireRole("ADMIN");
    await db.report.update({ where: { id }, data: { resolved: true } });
    await audit(admin.id, "report.resolve", id);
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
