import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { ListingWizard, type WizardData } from "@/components/ListingWizard";

export const metadata = { title: "Edit Listing" };
export const dynamic = "force-dynamic";

export default async function EditListing({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const s = await requireRole("SELLER", "ADMIN");
  const l = await db.listing.findUnique({
    where: { id },
    include: { images: { orderBy: { position: "asc" } } },
  });
  if (!l || (l.sellerId !== s.id && s.role !== "ADMIN")) notFound();
  const categories = await db.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true } });
  const str = (v: number | null) => (v === null ? "" : String(v));
  const initial: WizardData = {
    title: l.title, description: l.description, type: l.type, categoryId: l.categoryId ?? "",
    price: l.price.toString(), negotiable: l.negotiable,
    province: l.province, city: l.city, district: l.district, village: l.village ?? "", address: l.address,
    latitude: str(l.latitude), longitude: str(l.longitude),
    landArea: str(l.landArea), buildingArea: str(l.buildingArea), width: str(l.width), length: str(l.length),
    floor: String(l.floor), yearBuilt: str(l.yearBuilt), electricity: l.electricity ?? "", water: l.water ?? "",
    condition: l.condition, facilities: l.facilities,
    images: l.images.map((i) => i.url),
    primaryIndex: Math.max(0, l.images.findIndex((i) => i.isPrimary)),
    videoUrl: l.videoUrl ?? "",
  };
  return (
    <div>
      <h1 className="mb-2 text-2xl font-bold">Edit Listing</h1>
      <p className="mb-6 text-sm text-navy-500">Perubahan akan dikirim ulang untuk verifikasi admin.</p>
      <ListingWizard categories={categories} initial={initial} listingId={id} />
    </div>
  );
}
