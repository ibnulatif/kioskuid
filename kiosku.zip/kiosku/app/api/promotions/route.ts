import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { PLANS } from "@/lib/utils";
import { activatePromotion } from "@/lib/promo";

/** Membuat transaksi promosi & token pembayaran Midtrans Snap. */
export async function POST(req: Request) {
  try {
    const s = await requireRole("SELLER");
    const { listingId, plan } = (await req.json()) as { listingId?: string; plan?: "PREMIUM" | "PRO" };
    if (!listingId || (plan !== "PREMIUM" && plan !== "PRO")) throw new HttpError(422, "Data tidak valid.");
    const listing = await db.listing.findUnique({ where: { id: listingId } });
    if (!listing || listing.sellerId !== s.id) throw new HttpError(404, "Listing tidak ditemukan.");
    if (listing.status !== "PUBLISHED") throw new HttpError(422, "Hanya listing terbit yang dapat dipromosikan.");

    const amount = PLANS[plan].price;
    const orderId = `KIOSKU-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const trx = await db.transaction.create({
      data: { orderId, userId: s.id, listingId, plan, amount },
    });

    const serverKey = process.env.MIDTRANS_SERVER_KEY;
    if (!serverKey) {
      // Mode development tanpa kunci Midtrans: aktifkan langsung agar alur dapat diuji.
      await activatePromotion(trx.id);
      return ok({ devMode: true, orderId });
    }

    const isProd = !serverKey.startsWith("SB-");
    const res = await fetch(`https://app${isProd ? "" : ".sandbox"}.midtrans.com/snap/v1/transactions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Basic " + Buffer.from(serverKey + ":").toString("base64"),
      },
      body: JSON.stringify({
        transaction_details: { order_id: orderId, gross_amount: amount },
        item_details: [{ id: plan, price: amount, quantity: 1, name: `Promosi ${plan} - ${listing.title}`.slice(0, 50) }],
        customer_details: { first_name: s.name, email: s.email },
      }),
    });
    const json = (await res.json()) as { token?: string };
    if (!res.ok || !json.token) throw new HttpError(502, "Gagal membuat pembayaran.");
    await db.transaction.update({ where: { id: trx.id }, data: { snapToken: json.token } });
    return ok({ token: json.token, orderId });
  } catch (e) {
    return fail(e);
  }
}
