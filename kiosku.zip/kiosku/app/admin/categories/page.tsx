import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { CategoryManager } from "@/components/CategoryManager";

export const metadata = { title: "Kategori" };
export const dynamic = "force-dynamic";

export default async function AdminCategories() {
  await requireRole("ADMIN");
  const items = await db.category.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { listings: true } } },
  });
  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">Kategori</h1>
      <CategoryManager items={items} />
    </div>
  );
}
