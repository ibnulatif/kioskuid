import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate } from "@/lib/utils";
import { EmptyState } from "@/components/EmptyState";

export const metadata = { title: "Favorit pada Listing Saya" };
export const dynamic = "force-dynamic";

export default async function SellerFavorites() {
  const s = await requireRole("SELLER", "ADMIN");
  const favs = await db.favorite.findMany({
    where: { listing: { sellerId: s.id } },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { listing: { select: { title: true } }, user: { select: { name: true } } },
  });
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Favorit</h1>
      {favs.length === 0 ? (
        <EmptyState title="Belum ada yang memfavoritkan" text="Listing Anda akan muncul di sini saat ada yang menyimpannya." />
      ) : (
        <div className="card divide-y divide-navy-100">
          {favs.map((f) => (
            <div key={f.userId + f.listingId} className="flex justify-between gap-3 p-4 text-sm">
              <span><b>{f.user.name}</b> menyimpan “{f.listing.title}”</span>
              <span className="text-navy-500">{formatDate(f.createdAt)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
