import { StaticPage } from "@/components/StaticPage";

export const metadata = { title: "Tentang KIOSKU" };

export default function Page() {
  return (
    <StaticPage title="Tentang KIOSKU">
      <p>KIOSKU adalah marketplace khusus tempat usaha di Indonesia: kios, toko kecil, ruko, lapak, dan tempat kuliner untuk dijual maupun disewa.</p>
      <p>Kami mempertemukan pemilik kios, agen properti, dan pelaku usaha agar menemukan lokasi yang tepat dengan cepat dan aman.</p>
      <h2>Temukan tempat, mulai usaha.</h2>
      <p>Badge “Terverifikasi KIOSKU” menunjukkan identitas penjual telah kami tinjau. Badge ini bukan jaminan kepemilikan properti; selalu periksa dokumen dan lokasi sebelum bertransaksi.</p>
    </StaticPage>
  );
}
