import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { VerificationForm } from "@/components/VerificationForm";

export const metadata = { title: "Profil Seller" };
export const dynamic = "force-dynamic";

const label: Record<string, string> = {
  UNVERIFIED: "Belum terverifikasi",
  PENDING: "Menunggu peninjauan",
  VERIFIED: "✓ Terverifikasi KIOSKU",
  REJECTED: "Ditolak",
};

export default async function SellerProfile() {
  const s = await requireRole("SELLER", "ADMIN");
  const u = await db.user.findUniqueOrThrow({ where: { id: s.id } });
  const last = await db.verification.findFirst({ where: { userId: s.id }, orderBy: { createdAt: "desc" } });
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Profil</h1>
      <div className="card space-y-1 p-6">
        <p className="font-semibold">{u.name}</p>
        <p className="text-sm text-navy-500">{u.email} · {u.phone ?? "-"}</p>
        <p className="pt-2 text-sm">Status verifikasi: <b>{label[u.verifiedStatus]}</b></p>
        {u.verifiedStatus === "REJECTED" && last?.rejectNote && (
          <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">Alasan: {last.rejectNote}</p>
        )}
        <p className="pt-2 text-xs text-navy-500">
          “Terverifikasi KIOSKU” berarti identitas penjual telah ditinjau. Ini bukan jaminan kepemilikan properti.
        </p>
      </div>
      {(u.verifiedStatus === "UNVERIFIED" || u.verifiedStatus === "REJECTED") && (
        <div className="card p-6">
          <h2 className="mb-4 text-lg font-bold">Ajukan verifikasi penjual</h2>
          <VerificationForm defaultName={u.name} defaultPhone={u.phone ?? ""} />
        </div>
      )}
    </div>
  );
}
