import { StaticPage } from "@/components/StaticPage";

export const metadata = { title: "Kebijakan Privasi" };

export default function Page() {
  return (
    <StaticPage title="Kebijakan Privasi">
      <p>KIOSKU mengumpulkan data akun (nama, email, nomor WhatsApp) dan data listing untuk menjalankan layanan.</p>
      <h2>Dokumen verifikasi</h2>
      <p>KTP dan selfie hanya dipakai untuk verifikasi penjual dan hanya dapat dilihat admin.</p>
      <h2>Keamanan</h2>
      <p>Password disimpan dalam bentuk hash. Kami tidak menjual data pribadi Anda.</p>
    </StaticPage>
  );
}
