import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { notify } from "@/lib/notify";

export async function POST(req: Request) {
  try {
    const s = await requireRole();
    const { listingId } = (await req.json()) as { listingId?: string };
    if (!listingId) return ok({ error: "listingId wajib." }, 422);
    const key = { userId_listingId: { userId: s.id, listingId } };
    const existing = await db.favorite.findUnique({ where: key });
    if (existing) {
      await db.favorite.delete({ where: key });
      return ok({ favorited: false });
    }
    const listing = await db.listing.findUnique({ where: { id: listingId }, select: { sellerId: true, title: true } });
    if (!listing) return ok({ error: "Listing tidak ditemukan." }, 404);
    await db.favorite.create({ data: { userId: s.id, listingId } });
    if (listing.sellerId !== s.id) {
      await notify(listing.sellerId, "Listing difavoritkan", `${s.name} menyimpan "${listing.title}" ke favorit.`, "/dashboard/favorites");
    }
    return ok({ favorited: true });
  } catch (e) {
    return fail(e);
  }
}
