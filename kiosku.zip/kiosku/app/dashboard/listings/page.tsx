import Link from "next/link";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatRupiah, listingPath } from "@/lib/utils";
import { EmptyState } from "@/components/EmptyState";
import { ListingRowActions } from "@/components/ListingRowActions";

export const metadata = { title: "Listing Saya" };
export const dynamic = "force-dynamic";

const statusStyle: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-800",
  PUBLISHED: "bg-emerald-100 text-emerald-800",
  REJECTED: "bg-red-100 text-red-700",
  BLOCKED: "bg-red-100 text-red-700",
  SOLD: "bg-navy-100 text-navy",
  RENTED: "bg-navy-100 text-navy",
};

export default async function MyListings() {
  const s = await requireRole("SELLER", "ADMIN");
  const items = await db.listing.findMany({
    where: { sellerId: s.id },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { favorites: true } } },
  });
  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Listing Saya</h1>
        <Link href="/dashboard/listings/create" className="btn-primary">+ Tambah Listing</Link>
      </div>
      {items.length === 0 ? (
        <EmptyState title="Belum ada listing" text="Pasang listing pertama Anda." href="/dashboard/listings/create" cta="Tambah Listing" />
      ) : (
        <div className="space-y-3">
          {items.map((l) => (
            <div key={l.id} className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <Link href={listingPath(l)} className="block truncate font-semibold hover:text-brand">{l.title}</Link>
                <p className="text-sm text-navy-500">{formatRupiah(l.price)} · 👁 {l.views} · ❤️ {l._count.favorites}</p>
                {l.status === "REJECTED" && l.rejectReason && (
                  <p className="mt-1 rounded-lg bg-red-50 p-2 text-sm text-red-700">Ditolak: {l.rejectReason}</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className={`badge ${statusStyle[l.status]}`}>{l.status}</span>
                <ListingRowActions id={l.id} status={l.status} type={l.type} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
