import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";

const menu = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/listings", label: "Moderasi Listing" },
  { href: "/admin/sellers", label: "Verifikasi Penjual" },
  { href: "/admin/users", label: "Pengguna" },
  { href: "/admin/reports", label: "Laporan" },
  { href: "/admin/categories", label: "Kategori" },
  { href: "/admin/transactions", label: "Transaksi" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const s = await getSession();
  if (!s) redirect("/login?next=/admin");
  if (s.role !== "ADMIN") redirect("/");
  return (
    <div className="container-x flex flex-col gap-6 py-8 lg:flex-row">
      <nav className="card flex shrink-0 gap-1 overflow-x-auto p-2 lg:w-60 lg:flex-col lg:self-start">
        {menu.map((m) => (
          <Link key={m.href} href={m.href} className="whitespace-nowrap rounded-xl px-4 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand">
            {m.label}
          </Link>
        ))}
      </nav>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}
