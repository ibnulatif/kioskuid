import { StaticPage } from "@/components/StaticPage";

export const metadata = { title: "Kontak" };

export default function Page() {
  return (
    <StaticPage title="Kontak">
      <p>Email: halo@kiosku.id</p>
      <p>Jam layanan: Senin–Jumat, 09.00–17.00 WIB.</p>
    </StaticPage>
  );
}
