import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { verificationSchema } from "@/lib/validation";
import { notify } from "@/lib/notify";

export async function POST(req: Request) {
  try {
    const s = await requireRole("SELLER");
    const user = await db.user.findUniqueOrThrow({ where: { id: s.id }, select: { verifiedStatus: true } });
    if (user.verifiedStatus === "PENDING") throw new HttpError(409, "Pengajuan Anda sedang ditinjau.");
    if (user.verifiedStatus === "VERIFIED") throw new HttpError(409, "Akun Anda sudah terverifikasi.");
    const data = verificationSchema.parse(await req.json());
    await db.$transaction([
      db.verification.create({ data: { ...data, userId: s.id } }),
      db.user.update({ where: { id: s.id }, data: { verifiedStatus: "PENDING" } }),
    ]);
    const admins = await db.user.findMany({ where: { role: "ADMIN" }, select: { id: true } });
    await Promise.all(admins.map((a) => notify(a.id, "Pengajuan verifikasi penjual", s.name, "/admin/sellers")));
    return ok({ ok: true }, 201);
  } catch (e) {
    return fail(e);
  }
}
