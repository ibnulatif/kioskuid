import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { fail, ok } from "@/lib/api";

export async function GET() {
  try {
    const s = await requireRole();
    const items = await db.notification.findMany({
      where: { userId: s.id },
      orderBy: { createdAt: "desc" },
      take: 20,
    });
    return ok({ items, unread: items.filter((n) => !n.read).length });
  } catch (e) {
    return fail(e);
  }
}

export async function POST() {
  try {
    const s = await requireRole();
    await db.notification.updateMany({ where: { userId: s.id, read: false }, data: { read: true } });
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
