import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { listingSchema } from "@/lib/validation";
import { searchListings, type SearchParams } from "@/lib/listings";
import { slugify } from "@/lib/utils";
import { notify } from "@/lib/notify";

export async function GET(req: Request) {
  try {
    const sp = Object.fromEntries(new URL(req.url).searchParams) as SearchParams;
    return ok(await searchListings(sp));
  } catch (e) {
    return fail(e);
  }
}

export async function POST(req: Request) {
  try {
    const s = await requireRole("SELLER", "ADMIN");
    rateLimit(`listing:${s.id}`, 20, 10 * 60_000);
    const { images, primaryIndex, ...data } = listingSchema.parse(await req.json());
    const slug = `${slugify(data.title)}-${Math.random().toString(36).slice(2, 7)}`;
    const listing = await db.listing.create({
      data: {
        ...data,
        categoryId: data.categoryId || null,
        price: BigInt(data.price),
        slug,
        sellerId: s.id,
        status: "PENDING",
        images: {
          create: images.map((url, i) => ({ url, position: i, isPrimary: i === primaryIndex })),
        },
      },
    });
    const admins = await db.user.findMany({ where: { role: "ADMIN" }, select: { id: true } });
    await Promise.all(admins.map((a) => notify(a.id, "Listing baru menunggu verifikasi", data.title, "/admin/listings")));
    return ok({ id: listing.id, status: listing.status }, 201);
  } catch (e) {
    return fail(e);
  }
}
