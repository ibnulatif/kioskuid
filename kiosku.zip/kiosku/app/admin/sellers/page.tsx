import Image from "next/image";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate } from "@/lib/utils";
import { VerificationActions } from "@/components/AdminActions";
import { EmptyState } from "@/components/EmptyState";

export const metadata = { title: "Verifikasi Penjual" };
export const dynamic = "force-dynamic";

export default async function AdminSellers() {
  await requireRole("ADMIN");
  const items = await db.verification.findMany({
    where: { status: "PENDING" },
    orderBy: { createdAt: "asc" },
    include: { user: { select: { name: true, email: true } } },
  });
  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">Verifikasi Penjual</h1>
      {items.length === 0 ? (
        <EmptyState title="Tidak ada pengajuan" text="Pengajuan verifikasi penjual akan tampil di sini." />
      ) : (
        <div className="space-y-4">
          {items.map((v) => (
            <div key={v.id} className="card space-y-3 p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold">{v.fullName} <span className="text-sm font-normal text-navy-500">({v.user.email})</span></p>
                  <p className="text-sm text-navy-500">HP {v.phone} · diajukan {formatDate(v.createdAt)}</p>
                </div>
                <VerificationActions id={v.id} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[["KTP", v.ktpUrl], ["Selfie", v.selfieUrl], ["Dokumen", v.docUrl]].map(([l, u]) =>
                  u ? (
                    <a key={l} href={u} target="_blank" rel="noreferrer" className="block">
                      <p className="mb-1 text-xs text-navy-500">{l}</p>
                      <div className="relative aspect-[4/3] overflow-hidden rounded-lg bg-navy-100">
                        <Image src={u} alt={l ?? ""} fill sizes="200px" className="object-cover" unoptimized />
                      </div>
                    </a>
                  ) : null,
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
