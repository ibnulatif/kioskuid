import { db } from "@/lib/db";
import { createSession, verifyPassword } from "@/lib/auth";
import { fail, ok, clientIp } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { loginSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    rateLimit(`login:${clientIp(req)}`, 10);
    const data = loginSchema.parse(await req.json());
    const user = await db.user.findUnique({ where: { email: data.email } });
    if (!user?.passwordHash || !(await verifyPassword(data.password, user.passwordHash))) {
      return ok({ error: "Email atau password salah." }, 401);
    }
    if (user.blocked) return ok({ error: "Akun Anda diblokir. Hubungi bantuan KIOSKU." }, 403);
    await createSession({ id: user.id, role: user.role, name: user.name, email: user.email }, data.remember);
    return ok({ ok: true, role: user.role });
  } catch (e) {
    return fail(e);
  }
}
