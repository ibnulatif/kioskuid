import { db } from "@/lib/db";
import { fail, ok } from "@/lib/api";
import { notify } from "@/lib/notify";

/**
 * Dipanggil harian (lihat vercel.json). Mengirim notifikasi "promosi hampir berakhir"
 * dan menurunkan paket yang sudah kedaluwarsa ke BASIC.
 * Lindungi dengan header Authorization: Bearer $CRON_SECRET.
 */
export async function GET(req: Request) {
  try {
    const secret = process.env.CRON_SECRET;
    if (!secret || req.headers.get("authorization") !== `Bearer ${secret}`) {
      return ok({ error: "Tidak diizinkan." }, 401);
    }
    const now = new Date();
    const soon = new Date(Date.now() + 3 * 86400000);

    const expiring = await db.listing.findMany({
      where: { plan: { not: "BASIC" }, planUntil: { gt: now, lte: soon } },
      select: { sellerId: true, title: true },
    });
    for (const l of expiring) {
      await notify(l.sellerId, "Promosi hampir berakhir", `Paket promosi "${l.title}" berakhir dalam 3 hari.`, "/dashboard/promotions");
    }

    const expired = await db.listing.updateMany({
      where: { plan: { not: "BASIC" }, planUntil: { lte: now } },
      data: { plan: "BASIC", featured: false, planUntil: null },
    });
    return ok({ notified: expiring.length, expired: expired.count });
  } catch (e) {
    return fail(e);
  }
}
