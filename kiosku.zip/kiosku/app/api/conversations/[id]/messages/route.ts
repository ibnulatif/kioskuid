import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { messageSchema } from "@/lib/validation";
import { notify } from "@/lib/notify";

type Ctx = { params: Promise<{ id: string }> };

async function ensureMember(id: string, userId: string) {
  const c = await db.conversation.findUnique({
    where: { id },
    include: { listing: { select: { title: true } } },
  });
  if (!c || (c.buyerId !== userId && c.sellerId !== userId)) throw new HttpError(404, "Percakapan tidak ditemukan.");
  return c;
}

/** Dipakai polling klien (?after=ISO) untuk pesan real-time. */
export async function GET(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const s = await requireRole();
    await ensureMember(id, s.id);
    const after = new URL(req.url).searchParams.get("after");
    await db.message.updateMany({
      where: { conversationId: id, senderId: { not: s.id }, readAt: null },
      data: { readAt: new Date() },
    });
    const messages = await db.message.findMany({
      where: { conversationId: id, ...(after ? { createdAt: { gt: new Date(after) } } : {}) },
      orderBy: { createdAt: "asc" },
      take: 200,
    });
    return ok(messages);
  } catch (e) {
    return fail(e);
  }
}

export async function POST(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const s = await requireRole();
    rateLimit(`msg:${s.id}`, 30);
    const conv = await ensureMember(id, s.id);
    const { body } = messageSchema.parse(await req.json());
    const msg = await db.message.create({ data: { conversationId: id, senderId: s.id, body } });
    await db.conversation.update({ where: { id }, data: { updatedAt: new Date() } });
    const other = conv.buyerId === s.id ? conv.sellerId : conv.buyerId;
    await notify(other, "Pesan baru", `${s.name}: ${body.slice(0, 80)}`, `/messages?c=${id}`);
    return ok(msg, 201);
  } catch (e) {
    return fail(e);
  }
}
