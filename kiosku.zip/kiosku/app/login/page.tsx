import { Suspense } from "react";
import { LoginForm } from "@/components/AuthForms";

export const metadata = { title: "Masuk" };

export default function LoginPage() {
  return (
    <div className="container-x grid place-items-center py-12">
      <div className="card w-full max-w-md p-8">
        <h1 className="mb-1 text-2xl font-bold">Masuk ke KIOSKU</h1>
        <p className="mb-6 text-sm text-navy-500">Temukan tempat, mulai usaha.</p>
        <Suspense fallback={null}>
          <LoginForm />
        </Suspense>
      </div>
    </div>
  );
}
