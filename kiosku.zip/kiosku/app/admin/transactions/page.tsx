import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate, formatRupiah } from "@/lib/utils";
import { EmptyState } from "@/components/EmptyState";

export const metadata = { title: "Transaksi" };
export const dynamic = "force-dynamic";

export default async function AdminTransactions() {
  await requireRole("ADMIN");
  const items = await db.transaction.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { user: { select: { name: true } }, listing: { select: { title: true } } },
  });
  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">Transaksi</h1>
      {items.length === 0 ? (
        <EmptyState title="Belum ada transaksi" text="Pembelian paket promosi akan tampil di sini." />
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead className="border-b border-navy-100 text-xs uppercase text-navy-500">
              <tr>{["Order", "Pengguna", "Listing", "Paket", "Jumlah", "Status", "Tanggal"].map((h) => <th key={h} className="p-3">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-navy-100">
              {items.map((t) => (
                <tr key={t.id}>
                  <td className="p-3 font-mono text-xs">{t.orderId}</td>
                  <td className="p-3">{t.user.name}</td>
                  <td className="p-3">{t.listing.title}</td>
                  <td className="p-3">{t.plan}</td>
                  <td className="p-3">{formatRupiah(t.amount)}</td>
                  <td className="p-3">{t.status}</td>
                  <td className="p-3">{formatDate(t.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
