import Link from "next/link";
import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate, formatRupiah } from "@/lib/utils";
import { ListingActions } from "@/components/AdminActions";
import { EmptyState } from "@/components/EmptyState";

export const metadata = { title: "Moderasi Listing" };
export const dynamic = "force-dynamic";

const STATUSES = ["PENDING", "PUBLISHED", "REJECTED", "BLOCKED", "SOLD", "RENTED"] as const;
type S = (typeof STATUSES)[number];

export default async function AdminListings({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  await requireRole("ADMIN");
  const { status } = await searchParams;
  const filter = STATUSES.includes(status as S) ? (status as S) : undefined;
  const items = await db.listing.findMany({
    where: filter ? { status: filter } : {},
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    take: 100,
    include: { seller: { select: { name: true } }, images: { take: 1, orderBy: { position: "asc" } } },
  });
  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">Moderasi Listing</h1>
      <div className="mb-4 flex flex-wrap gap-2 text-sm">
        <Link href="/admin/listings" className={`badge px-3 py-1.5 ${!filter ? "bg-brand text-white" : "bg-navy-100"}`}>Semua</Link>
        {STATUSES.map((s) => (
          <Link key={s} href={`/admin/listings?status=${s}`} className={`badge px-3 py-1.5 ${filter === s ? "bg-brand text-white" : "bg-navy-100"}`}>{s}</Link>
        ))}
      </div>
      {items.length === 0 ? (
        <EmptyState title="Tidak ada listing" />
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[800px] text-left text-sm">
            <thead className="border-b border-navy-100 text-xs uppercase text-navy-500">
              <tr>{["Listing", "Seller", "Harga", "Lokasi", "Tanggal", "Status", "Action"].map((h) => <th key={h} className="p-3">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-navy-100">
              {items.map((l) => (
                <tr key={l.id}>
                  <td className="p-3 font-medium">{l.title}</td>
                  <td className="p-3">{l.seller.name}</td>
                  <td className="p-3">{formatRupiah(l.price)}</td>
                  <td className="p-3">{l.district}, {l.city}</td>
                  <td className="p-3">{formatDate(l.createdAt)}</td>
                  <td className="p-3"><span className="badge bg-navy-100">{l.status}</span></td>
                  <td className="p-3"><ListingActions id={l.id} status={l.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
