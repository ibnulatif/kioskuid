export default function Loading() {
  return (
    <div className="container-x py-8">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="card h-80 animate-pulse bg-navy-100/50" />
        ))}
      </div>
    </div>
  );
}
