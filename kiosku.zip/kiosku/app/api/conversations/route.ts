import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";

export async function GET() {
  try {
    const s = await requireRole();
    const convs = await db.conversation.findMany({
      where: { OR: [{ buyerId: s.id }, { sellerId: s.id }] },
      orderBy: { updatedAt: "desc" },
      include: {
        listing: { select: { id: true, title: true } },
        buyer: { select: { id: true, name: true } },
        seller: { select: { id: true, name: true } },
        messages: { orderBy: { createdAt: "desc" }, take: 1 },
        _count: { select: { messages: { where: { readAt: null, senderId: { not: s.id } } } } },
      },
    });
    return ok(convs);
  } catch (e) {
    return fail(e);
  }
}

/** Mulai (atau lanjutkan) percakapan untuk sebuah listing. */
export async function POST(req: Request) {
  try {
    const s = await requireRole();
    const { listingId, body } = (await req.json()) as { listingId?: string; body?: string };
    if (!listingId) throw new HttpError(422, "listingId wajib.");
    const listing = await db.listing.findUnique({ where: { id: listingId }, select: { sellerId: true } });
    if (!listing) throw new HttpError(404, "Listing tidak ditemukan.");
    if (listing.sellerId === s.id) throw new HttpError(422, "Anda tidak dapat chat dengan diri sendiri.");
    const conv = await db.conversation.upsert({
      where: { listingId_buyerId: { listingId, buyerId: s.id } },
      update: {},
      create: { listingId, buyerId: s.id, sellerId: listing.sellerId },
    });
    if (body?.trim()) {
      await db.message.create({ data: { conversationId: conv.id, senderId: s.id, body: body.trim().slice(0, 2000) } });
    }
    return ok({ id: conv.id });
  } catch (e) {
    return fail(e);
  }
}
