import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { listingSchema } from "@/lib/validation";

type Ctx = { params: Promise<{ id: string }> };

async function ownListing(id: string, userId: string, isAdmin: boolean) {
  const l = await db.listing.findUnique({ where: { id }, select: { id: true, sellerId: true } });
  if (!l) throw new HttpError(404, "Listing tidak ditemukan.");
  if (!isAdmin && l.sellerId !== userId) throw new HttpError(403, "Bukan listing Anda.");
}

export async function PUT(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const s = await requireRole("SELLER", "ADMIN");
    await ownListing(id, s.id, s.role === "ADMIN");
    const { images, primaryIndex, ...data } = listingSchema.parse(await req.json());
    await db.$transaction([
      db.listingImage.deleteMany({ where: { listingId: id } }),
      db.listing.update({
        where: { id },
        data: {
          ...data,
          categoryId: data.categoryId || null,
          price: BigInt(data.price),
          // perubahan oleh seller kembali ke antrean verifikasi
          status: s.role === "ADMIN" ? undefined : "PENDING",
          rejectReason: null,
          images: { create: images.map((url, i) => ({ url, position: i, isPrimary: i === primaryIndex })) },
        },
      }),
    ]);
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const s = await requireRole("SELLER", "ADMIN");
    await ownListing(id, s.id, s.role === "ADMIN");
    const { status } = (await req.json()) as { status?: string };
    if (status !== "SOLD" && status !== "RENTED") throw new HttpError(422, "Status tidak valid.");
    await db.listing.update({ where: { id }, data: { status } });
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const s = await requireRole("SELLER", "ADMIN");
    await ownListing(id, s.id, s.role === "ADMIN");
    await db.listing.delete({ where: { id } });
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
