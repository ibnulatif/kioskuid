import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { audit, notify } from "@/lib/notify";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const admin = await requireRole("ADMIN");
    const { action, reason } = (await req.json()) as { action?: string; reason?: string };
    const listing = await db.listing.findUnique({ where: { id }, select: { id: true, title: true, sellerId: true } });
    if (!listing) throw new HttpError(404, "Listing tidak ditemukan.");

    if (action === "approve") {
      await db.listing.update({ where: { id }, data: { status: "PUBLISHED", rejectReason: null } });
      await notify(listing.sellerId, "Listing disetujui", `"${listing.title}" kini tayang di KIOSKU.`, "/dashboard/listings");
    } else if (action === "reject") {
      if (!reason?.trim()) throw new HttpError(422, "Alasan penolakan wajib diisi.");
      await db.listing.update({ where: { id }, data: { status: "REJECTED", rejectReason: reason.trim() } });
      await notify(listing.sellerId, "Listing ditolak", `"${listing.title}" ditolak: ${reason.trim()}`, "/dashboard/listings");
    } else if (action === "block") {
      await db.listing.update({ where: { id }, data: { status: "BLOCKED" } });
    } else if (action === "delete") {
      await db.listing.delete({ where: { id } });
    } else {
      throw new HttpError(422, "Aksi tidak dikenal.");
    }
    await audit(admin.id, `listing.${action}`, id, reason ? { reason } : undefined);
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
