import { Suspense } from "react";
import { RegisterForm } from "@/components/AuthForms";

export const metadata = { title: "Daftar" };

export default function RegisterPage() {
  return (
    <div className="container-x grid place-items-center py-12">
      <div className="card w-full max-w-md p-8">
        <h1 className="mb-1 text-2xl font-bold">Daftar di KIOSKU</h1>
        <p className="mb-6 text-sm text-navy-500">Buat akun gratis dalam semenit.</p>
        <Suspense fallback={null}>
          <RegisterForm />
        </Suspense>
      </div>
    </div>
  );
}
