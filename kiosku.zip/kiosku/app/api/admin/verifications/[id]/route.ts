import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { audit, notify } from "@/lib/notify";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const admin = await requireRole("ADMIN");
    const { action, note } = (await req.json()) as { action?: string; note?: string };
    const v = await db.verification.findUnique({ where: { id } });
    if (!v) throw new HttpError(404, "Pengajuan tidak ditemukan.");

    if (action === "approve") {
      await db.$transaction([
        db.verification.update({ where: { id }, data: { status: "VERIFIED" } }),
        db.user.update({ where: { id: v.userId }, data: { verifiedStatus: "VERIFIED" } }),
      ]);
      await notify(v.userId, "Verifikasi berhasil", "Akun Anda kini Terverifikasi KIOSKU.", "/dashboard/profile");
    } else if (action === "reject") {
      if (!note?.trim()) throw new HttpError(422, "Catatan penolakan wajib diisi.");
      await db.$transaction([
        db.verification.update({ where: { id }, data: { status: "REJECTED", rejectNote: note.trim() } }),
        db.user.update({ where: { id: v.userId }, data: { verifiedStatus: "REJECTED" } }),
      ]);
      await notify(v.userId, "Verifikasi ditolak", note.trim(), "/dashboard/profile");
    } else {
      throw new HttpError(422, "Aksi tidak dikenal.");
    }
    await audit(admin.id, `verification.${action}`, id);
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
