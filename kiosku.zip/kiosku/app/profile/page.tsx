import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";

export const metadata = { title: "Profil" };
export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const s = await getSession();
  if (!s) redirect("/login?next=/profile");
  const u = await db.user.findUniqueOrThrow({ where: { id: s.id } });
  return (
    <div className="container-x max-w-2xl py-8">
      <h1 className="mb-6 text-2xl font-bold">Profil Saya</h1>
      <div className="card space-y-3 p-6">
        <p><span className="text-navy-500">Nama:</span> <b>{u.name}</b></p>
        <p><span className="text-navy-500">Email:</span> {u.email}</p>
        <p><span className="text-navy-500">WhatsApp:</span> {u.phone ?? "-"}</p>
        <p><span className="text-navy-500">Peran:</span> {u.role}</p>
        <div className="flex flex-wrap gap-2 pt-2">
          <Link href="/favorites" className="btn-outline">Favorit</Link>
          <Link href="/messages" className="btn-outline">Pesan</Link>
          {u.role === "SELLER" && <Link href="/dashboard" className="btn-primary">Dashboard Seller</Link>}
          {u.role === "ADMIN" && <Link href="/admin" className="btn-primary">Panel Admin</Link>}
        </div>
      </div>
    </div>
  );
}
