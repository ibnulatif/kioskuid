import { notFound, redirect } from "next/navigation";
import { db } from "@/lib/db";
import { listingPath } from "@/lib/utils";

export const dynamic = "force-dynamic";

/** URL /listing/[id] dialihkan ke URL SEO kanonis. */
export default async function ListingRedirect({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = await db.listing.findUnique({ where: { id }, select: { slug: true, type: true, city: true } });
  if (!l) notFound();
  redirect(listingPath(l));
}
