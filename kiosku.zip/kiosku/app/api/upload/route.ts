import { createHash } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { requireRole } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { HttpError } from "@/lib/auth";

const MAX_IMAGE = 5 * 1024 * 1024;
const MAX_VIDEO = 40 * 1024 * 1024;
const IMAGE_TYPES: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
const VIDEO_TYPES: Record<string, string> = { "video/mp4": "mp4", "video/webm": "webm" };

export async function POST(req: Request) {
  try {
    const s = await requireRole();
    rateLimit(`upload:${s.id}`, 40, 10 * 60_000);
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new HttpError(422, "File tidak ditemukan.");

    const isVideo = file.type.startsWith("video/");
    const ext = (isVideo ? VIDEO_TYPES : IMAGE_TYPES)[file.type];
    if (!ext) throw new HttpError(422, "Format file tidak didukung (JPG, PNG, WEBP, MP4, WEBM).");
    if (file.size > (isVideo ? MAX_VIDEO : MAX_IMAGE)) {
      throw new HttpError(422, isVideo ? "Video maksimal 40 MB." : "Foto maksimal 5 MB.");
    }

    const cloud = process.env.CLOUDINARY_CLOUD_NAME;
    const key = process.env.CLOUDINARY_API_KEY;
    const secretKey = process.env.CLOUDINARY_API_SECRET;

    if (cloud && key && secretKey) {
      const timestamp = Math.floor(Date.now() / 1000);
      const folder = "kiosku";
      const signature = createHash("sha1").update(`folder=${folder}&timestamp=${timestamp}${secretKey}`).digest("hex");
      const body = new FormData();
      body.append("file", file);
      body.append("api_key", key);
      body.append("timestamp", String(timestamp));
      body.append("folder", folder);
      body.append("signature", signature);
      const res = await fetch(`https://api.cloudinary.com/v1_1/${cloud}/${isVideo ? "video" : "image"}/upload`, {
        method: "POST",
        body,
      });
      const json = (await res.json()) as { secure_url?: string };
      if (!res.ok || !json.secure_url) throw new HttpError(502, "Gagal mengunggah ke penyimpanan.");
      return ok({ url: json.secure_url });
    }

    // Fallback development: simpan lokal di public/uploads
    const dir = path.join(process.cwd(), "public", "uploads");
    await mkdir(dir, { recursive: true });
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    await writeFile(path.join(dir, name), Buffer.from(await file.arrayBuffer()));
    return ok({ url: `/uploads/${name}` });
  } catch (e) {
    return fail(e);
  }
}
