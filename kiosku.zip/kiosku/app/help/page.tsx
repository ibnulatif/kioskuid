import { StaticPage } from "@/components/StaticPage";

export const metadata = { title: "Pusat Bantuan" };

export default function Page() {
  return (
    <StaticPage title="Pusat Bantuan & Cara Kerja">
      <h2>Mencari kios</h2>
      <p>Gunakan kolom pencarian atau filter harga, lokasi, luas, dan fasilitas. Simpan listing favorit dan hubungi penjual lewat chat atau WhatsApp.</p>
      <h2>Memasang listing</h2>
      <p>Daftar sebagai penjual, isi wizard 5 langkah, lalu kirim untuk verifikasi. Listing tayang setelah disetujui admin.</p>
      <h2>Promosi listing</h2>
      <p>Paket PREMIUM (Rp49.000) dan PRO (Rp99.000) membuat listing tampil lebih tinggi dan di homepage.</p>
      <h2>Lupa password?</h2>
      <p>Hubungi kami melalui halaman Kontak dengan email akun Anda.</p>
    </StaticPage>
  );
}
