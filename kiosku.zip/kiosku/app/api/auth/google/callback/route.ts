import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const base = process.env.NEXT_PUBLIC_APP_URL || url.origin;
  const code = url.searchParams.get("code");
  if (!code) return NextResponse.redirect(`${base}/login?error=google_failed`);

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID ?? "",
        client_secret: process.env.GOOGLE_CLIENT_SECRET ?? "",
        redirect_uri: `${base}/api/auth/google/callback`,
        grant_type: "authorization_code",
      }),
    });
    const token = (await tokenRes.json()) as { access_token?: string };
    if (!token.access_token) throw new Error("no token");

    const infoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
      headers: { Authorization: `Bearer ${token.access_token}` },
    });
    const info = (await infoRes.json()) as { email?: string; name?: string; picture?: string; email_verified?: boolean };
    if (!info.email || !info.email_verified) throw new Error("email not verified");

    const email = info.email.toLowerCase();
    let user = await db.user.findUnique({ where: { email } });
    if (!user) {
      user = await db.user.create({
        data: { email, name: info.name ?? email.split("@")[0], avatar: info.picture, role: "USER" },
      });
    }
    if (user.blocked) return NextResponse.redirect(`${base}/login?error=blocked`);
    await createSession({ id: user.id, role: user.role, name: user.name, email: user.email }, true);
    return NextResponse.redirect(`${base}${user.role === "ADMIN" ? "/admin" : user.role === "SELLER" ? "/dashboard" : "/"}`);
  } catch {
    return NextResponse.redirect(`${base}/login?error=google_failed`);
  }
}
