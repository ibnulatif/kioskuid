import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatRupiah } from "@/lib/utils";
import { BarChart } from "@/components/BarChart";

export const metadata = { title: "Admin" };
export const dynamic = "force-dynamic";

function lastMonths(n: number) {
  const out: { key: string; label: string; start: Date; end: Date }[] = [];
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
    out.push({ key: start.toISOString(), label: new Intl.DateTimeFormat("id-ID", { month: "short" }).format(start), start, end });
  }
  return out;
}

export default async function AdminDashboard() {
  await requireRole("ADMIN");
  const [users, sellers, listings, active, pending, sold, rented, trx, revenue] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { role: "SELLER" } }),
    db.listing.count(),
    db.listing.count({ where: { status: "PUBLISHED" } }),
    db.listing.count({ where: { status: "PENDING" } }),
    db.listing.count({ where: { status: "SOLD" } }),
    db.listing.count({ where: { status: "RENTED" } }),
    db.transaction.count(),
    db.transaction.aggregate({ where: { status: "PAID" }, _sum: { amount: true } }),
  ]);

  const months = lastMonths(6);
  const series = await Promise.all(
    months.map(async (m) => {
      const range = { gte: m.start, lt: m.end };
      const [l, u, t, r] = await Promise.all([
        db.listing.count({ where: { createdAt: range } }),
        db.user.count({ where: { createdAt: range } }),
        db.transaction.count({ where: { createdAt: range } }),
        db.transaction.aggregate({ where: { status: "PAID", paidAt: range }, _sum: { amount: true } }),
      ]);
      return { label: m.label, l, u, t, r: r._sum.amount ?? 0 };
    }),
  );

  const stats: [string, string | number][] = [
    ["Total pengguna", users], ["Total seller", sellers], ["Total listing", listings],
    ["Listing aktif", active], ["Listing pending", pending], ["Listing terjual", sold],
    ["Listing tersewa", rented], ["Total transaksi", trx], ["Revenue", formatRupiah(revenue._sum.amount ?? 0)],
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard Admin</h1>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {stats.map(([k, v]) => (
          <div key={k} className="card p-5">
            <p className="text-sm text-navy-500">{k}</p>
            <p className="mt-1 text-2xl font-extrabold">{v}</p>
          </div>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <BarChart title="Listing per bulan" data={series.map((s) => ({ label: s.label, value: s.l }))} />
        <BarChart title="Pengguna baru" data={series.map((s) => ({ label: s.label, value: s.u }))} />
        <BarChart title="Transaksi" data={series.map((s) => ({ label: s.label, value: s.t }))} />
        <BarChart title="Revenue" data={series.map((s) => ({ label: s.label, value: s.r }))} format={(n) => (n >= 1000 ? `${Math.round(n / 1000)}rb` : String(n))} />
      </div>
    </div>
  );
}
