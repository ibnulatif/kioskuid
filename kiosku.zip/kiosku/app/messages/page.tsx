import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { ChatClient } from "@/components/ChatClient";

export const metadata = { title: "Pesan" };
export const dynamic = "force-dynamic";

export default async function MessagesPage({ searchParams }: { searchParams: Promise<{ c?: string }> }) {
  const s = await getSession();
  if (!s) redirect("/login?next=/messages");
  const { c } = await searchParams;
  return (
    <div className="container-x py-6">
      <ChatClient meId={s.id} initialId={c} />
    </div>
  );
}
