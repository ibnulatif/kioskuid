import { db } from "@/lib/db";
import { createSession, hashPassword } from "@/lib/auth";
import { fail, ok, clientIp } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { registerSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    rateLimit(`register:${clientIp(req)}`, 8);
    const data = registerSchema.parse(await req.json());
    const exists = await db.user.findUnique({ where: { email: data.email } });
    if (exists) return ok({ error: "Email sudah terdaftar." }, 409);
    const user = await db.user.create({
      data: {
        name: data.name,
        email: data.email,
        phone: data.phone,
        passwordHash: await hashPassword(data.password),
        role: data.role,
      },
    });
    await createSession({ id: user.id, role: user.role, name: user.name, email: user.email });
    return ok({ ok: true, role: user.role }, 201);
  } catch (e) {
    return fail(e);
  }
}
