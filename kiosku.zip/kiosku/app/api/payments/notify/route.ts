import { createHash } from "node:crypto";
import { db } from "@/lib/db";
import { fail, ok } from "@/lib/api";
import { activatePromotion } from "@/lib/promo";

/** Webhook notifikasi Midtrans. Signature diverifikasi dengan SHA512. */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      order_id: string; status_code: string; gross_amount: string;
      signature_key: string; transaction_status: string; fraud_status?: string;
    };
    const serverKey = process.env.MIDTRANS_SERVER_KEY ?? "";
    const expected = createHash("sha512")
      .update(body.order_id + body.status_code + body.gross_amount + serverKey)
      .digest("hex");
    if (!serverKey || expected !== body.signature_key) return ok({ error: "Signature tidak valid." }, 403);

    const trx = await db.transaction.findUnique({ where: { orderId: body.order_id } });
    if (!trx) return ok({ error: "Transaksi tidak ditemukan." }, 404);

    const paid =
      (body.transaction_status === "settlement" || body.transaction_status === "capture") &&
      (body.fraud_status ?? "accept") === "accept";
    if (paid) await activatePromotion(trx.id);
    else if (["deny", "cancel", "failure"].includes(body.transaction_status)) {
      await db.transaction.update({ where: { id: trx.id }, data: { status: "FAILED" } });
    } else if (body.transaction_status === "expire") {
      await db.transaction.update({ where: { id: trx.id }, data: { status: "EXPIRED" } });
    }
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
