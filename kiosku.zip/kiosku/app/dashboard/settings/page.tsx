import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "Pengaturan" };
export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const s = await requireRole("SELLER", "ADMIN");
  const notifs = await db.notification.findMany({ where: { userId: s.id }, orderBy: { createdAt: "desc" }, take: 20 });
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Pengaturan</h1>
      <div className="card p-6">
        <h2 className="mb-3 font-bold">Notifikasi terbaru</h2>
        {notifs.length === 0 ? (
          <p className="text-sm text-navy-500">Belum ada notifikasi.</p>
        ) : (
          <ul className="divide-y divide-navy-100">
            {notifs.map((n) => (
              <li key={n.id} className="py-3 text-sm">
                <p className="font-semibold">{n.title}</p>
                <p className="text-navy-500">{n.body}</p>
                <p className="text-xs text-navy-500">{formatDate(n.createdAt)}</p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
