import { db } from "@/lib/db";
import { ListingWizard } from "@/components/ListingWizard";

export const metadata = { title: "Tambah Listing" };
export const dynamic = "force-dynamic";

export default async function CreateListing() {
  const categories = await db.category.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true } });
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Tambah Listing</h1>
      <ListingWizard categories={categories} />
    </div>
  );
}
