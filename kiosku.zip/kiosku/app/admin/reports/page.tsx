import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatDate, REPORT_REASONS } from "@/lib/utils";
import { ResolveReport } from "@/components/AdminActions";
import { EmptyState } from "@/components/EmptyState";

export const metadata = { title: "Laporan" };
export const dynamic = "force-dynamic";

export default async function AdminReports() {
  await requireRole("ADMIN");
  const reports = await db.report.findMany({
    orderBy: [{ resolved: "asc" }, { createdAt: "desc" }],
    take: 100,
    include: { listing: { select: { id: true, title: true } }, reporter: { select: { name: true } } },
  });
  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">Laporan</h1>
      {reports.length === 0 ? (
        <EmptyState title="Belum ada laporan" />
      ) : (
        <div className="space-y-3">
          {reports.map((r) => (
            <div key={r.id} className="card flex flex-col gap-2 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-semibold">{r.listing.title}</p>
                <p className="text-sm text-navy-500">
                  {REPORT_REASONS.find((x) => x.value === r.reason)?.label} · oleh {r.reporter.name} · {formatDate(r.createdAt)}
                </p>
                {r.detail && <p className="text-sm">{r.detail}</p>}
              </div>
              {r.resolved ? <span className="badge bg-emerald-100 text-emerald-800">Selesai</span> : <ResolveReport id={r.id} />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
