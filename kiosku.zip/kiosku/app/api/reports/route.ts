import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { reportSchema } from "@/lib/validation";

export async function POST(req: Request) {
  try {
    const s = await requireRole();
    rateLimit(`report:${s.id}`, 5, 10 * 60_000);
    const data = reportSchema.parse(await req.json());
    await db.report.create({ data: { ...data, reporterId: s.id } });
    return ok({ ok: true }, 201);
  } catch (e) {
    return fail(e);
  }
}
