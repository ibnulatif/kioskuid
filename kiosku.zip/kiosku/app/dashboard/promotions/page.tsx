import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { EmptyState } from "@/components/EmptyState";
import { PromoClient } from "@/components/PromoClient";

export const metadata = { title: "Promosi" };
export const dynamic = "force-dynamic";

export default async function PromotionsPage() {
  const s = await requireRole("SELLER", "ADMIN");
  const listings = await db.listing.findMany({
    where: { sellerId: s.id, status: "PUBLISHED" },
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true, plan: true, planUntil: true },
  });
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Promosi</h1>
      {listings.length === 0 ? (
        <EmptyState title="Belum ada listing terbit" text="Listing harus disetujui admin sebelum dapat dipromosikan." />
      ) : (
        <PromoClient listings={listings.map((l) => ({ ...l, planUntil: l.planUntil?.toISOString() ?? null }))} />
      )}
    </div>
  );
}
