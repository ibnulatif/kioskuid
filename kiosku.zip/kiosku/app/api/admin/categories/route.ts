import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { slugify } from "@/lib/utils";
import { audit } from "@/lib/notify";

export async function POST(req: Request) {
  try {
    const admin = await requireRole("ADMIN");
    const { name, icon } = (await req.json()) as { name?: string; icon?: string };
    if (!name?.trim()) throw new HttpError(422, "Nama kategori wajib diisi.");
    const slug = slugify(name);
    if (await db.category.findFirst({ where: { OR: [{ slug }, { name: name.trim() }] } })) {
      throw new HttpError(409, "Kategori sudah ada.");
    }
    const c = await db.category.create({ data: { name: name.trim(), slug, icon: icon?.trim() || null } });
    await audit(admin.id, "category.create", c.id);
    return ok(c, 201);
  } catch (e) {
    return fail(e);
  }
}

export async function DELETE(req: Request) {
  try {
    const admin = await requireRole("ADMIN");
    const id = new URL(req.url).searchParams.get("id");
    if (!id) throw new HttpError(422, "id wajib.");
    const used = await db.listing.count({ where: { categoryId: id } });
    if (used > 0) throw new HttpError(409, "Kategori masih dipakai listing.");
    await db.category.delete({ where: { id } });
    await audit(admin.id, "category.delete", id);
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
