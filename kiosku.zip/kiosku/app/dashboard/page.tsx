import { db } from "@/lib/db";
import { requireRole } from "@/lib/auth";
import { formatRupiah } from "@/lib/utils";

export const metadata = { title: "Dashboard Seller" };
export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const s = await requireRole("SELLER", "ADMIN");
  const [total, active, views, favs, chats, revenue] = await Promise.all([
    db.listing.count({ where: { sellerId: s.id } }),
    db.listing.count({ where: { sellerId: s.id, status: "PUBLISHED" } }),
    db.listing.aggregate({ where: { sellerId: s.id }, _sum: { views: true } }),
    db.favorite.count({ where: { listing: { sellerId: s.id } } }),
    db.conversation.count({ where: { sellerId: s.id } }),
    db.transaction.aggregate({ where: { userId: s.id, status: "PAID" }, _sum: { amount: true } }),
  ]);
  const stats = [
    ["Total Listing", total],
    ["Listing Aktif", active],
    ["Dilihat", views._sum.views ?? 0],
    ["Favorit", favs],
    ["Chat", chats],
    ["Revenue (promosi dibayar)", formatRupiah(revenue._sum.amount ?? 0)],
  ];
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Selamat datang, {s.name}</h1>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {stats.map(([k, v]) => (
          <div key={String(k)} className="card p-5">
            <p className="text-sm text-navy-500">{k}</p>
            <p className="mt-1 text-2xl font-extrabold">{v}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
