import { listingMetadata, ListingPageView } from "@/components/ListingPage";

type P = { params: Promise<{ city: string; slug: string }> };

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: P) {
  return listingMetadata((await params).slug);
}

export default async function Page({ params }: P) {
  return <ListingPageView slug={(await params).slug} expectedType="SALE" />;
}
