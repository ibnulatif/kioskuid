import { StaticPage } from "@/components/StaticPage";

export const metadata = { title: "Syarat & Ketentuan" };

export default function Page() {
  return (
    <StaticPage title="Syarat & Ketentuan">
      <p>Dengan menggunakan KIOSKU, Anda menyetujui ketentuan berikut.</p>
      <h2>1. Penggunaan</h2>
      <p>Pengguna wajib memberikan data yang benar. Listing yang menyesatkan atau palsu dapat dihapus dan akun diblokir.</p>
      <h2>2. Transaksi</h2>
      <p>KIOSKU adalah platform perantara dan bukan pihak dalam transaksi jual-beli atau sewa. Pengguna bertanggung jawab memeriksa lokasi, dokumen, dan identitas pihak lain.</p>
      <h2>3. Pembayaran promosi</h2>
      <p>Biaya paket promosi tidak dapat dikembalikan setelah paket aktif.</p>
    </StaticPage>
  );
}
