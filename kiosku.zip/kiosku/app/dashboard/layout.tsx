import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";

const menu = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/dashboard/listings", label: "Listing Saya" },
  { href: "/dashboard/listings/create", label: "Tambah Listing" },
  { href: "/messages", label: "Pesan" },
  { href: "/dashboard/favorites", label: "Favorit" },
  { href: "/dashboard/promotions", label: "Promosi" },
  { href: "/dashboard/profile", label: "Profil" },
  { href: "/dashboard/settings", label: "Pengaturan" },
];

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const s = await getSession();
  if (!s) redirect("/login?next=/dashboard");
  if (s.role !== "SELLER" && s.role !== "ADMIN") redirect("/register?role=SELLER");
  return (
    <div className="container-x flex flex-col gap-6 py-8 lg:flex-row">
      <nav className="card flex shrink-0 gap-1 overflow-x-auto p-2 lg:w-60 lg:flex-col lg:self-start">
        {menu.map((m) => (
          <Link key={m.href} href={m.href} className="whitespace-nowrap rounded-xl px-4 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand">
            {m.label}
          </Link>
        ))}
      </nav>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}
