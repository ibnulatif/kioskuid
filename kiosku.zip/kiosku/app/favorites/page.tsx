import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { cardSelect } from "@/lib/listings";
import { ListingCard } from "@/components/ListingCard";
import { EmptyState } from "@/components/EmptyState";

export const metadata = { title: "Kios Favorit Saya" };
export const dynamic = "force-dynamic";

export default async function FavoritesPage() {
  const s = await getSession();
  if (!s) redirect("/login?next=/favorites");
  const favs = await db.favorite.findMany({
    where: { userId: s.id, listing: { status: "PUBLISHED" } },
    orderBy: { createdAt: "desc" },
    include: { listing: { select: cardSelect } },
  });
  return (
    <div className="container-x py-8">
      <h1 className="mb-6 text-2xl font-bold">Kios Favorit Saya</h1>
      {favs.length === 0 ? (
        <EmptyState title="Belum ada favorit" text="Tekan ❤️ pada listing untuk menyimpannya di sini." href="/search" cta="Cari Kios" />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {favs.map((f) => (
            <ListingCard key={f.listingId} l={f.listing} favorited />
          ))}
        </div>
      )}
    </div>
  );
}
