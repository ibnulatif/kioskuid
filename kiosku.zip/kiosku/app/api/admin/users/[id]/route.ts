import { db } from "@/lib/db";
import { requireRole, HttpError } from "@/lib/auth";
import { fail, ok } from "@/lib/api";
import { audit } from "@/lib/notify";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const admin = await requireRole("ADMIN");
    if (id === admin.id) throw new HttpError(422, "Anda tidak dapat memblokir akun sendiri.");
    const { blocked } = (await req.json()) as { blocked?: boolean };
    if (typeof blocked !== "boolean") throw new HttpError(422, "Data tidak valid.");
    await db.user.update({ where: { id }, data: { blocked } });
    await audit(admin.id, blocked ? "user.block" : "user.unblock", id);
    return ok({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
