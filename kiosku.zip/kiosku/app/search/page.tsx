import type { Metadata } from "next";
import { Suspense } from "react";
import { searchListings, type SearchParams } from "@/lib/listings";
import { getFavoriteIds } from "@/lib/queries";
import { ListingCard } from "@/components/ListingCard";
import { FilterSidebar } from "@/components/FilterSidebar";
import { SortSelect } from "@/components/SortSelect";
import { Pagination } from "@/components/Pagination";
import { EmptyState } from "@/components/EmptyState";

export const metadata: Metadata = { title: "Cari Kios", alternates: { canonical: "/search" } };
export const dynamic = "force-dynamic";

export default async function SearchPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const sp = await searchParams;
  const [{ items, total, page, pages }, favs] = await Promise.all([searchListings(sp), getFavoriteIds()]);
  const flat = Object.fromEntries(
    Object.entries(sp).map(([k, v]) => [k, Array.isArray(v) ? v.join(",") : v]),
  ) as Record<string, string | undefined>;

  return (
    <div className="container-x py-8">
      <div className="flex flex-col gap-6 lg:flex-row">
        <Suspense fallback={<div className="card h-96 w-72 animate-pulse" />}>
          <FilterSidebar />
        </Suspense>
        <div className="min-w-0 flex-1">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-navy-500">
              <span className="font-semibold text-navy">{total}</span> kios ditemukan
              {sp.q ? <> untuk “{sp.q}”</> : null}
            </p>
            <Suspense fallback={null}>
              <SortSelect />
            </Suspense>
          </div>
          {items.length === 0 ? (
            <EmptyState
              title="Tidak ada kios yang cocok"
              text="Coba ubah kata kunci atau longgarkan filter pencarian Anda."
              href="/search"
              cta="Reset pencarian"
            />
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {items.map((l) => (
                <ListingCard key={l.id} l={l} favorited={favs.has(l.id)} />
              ))}
            </div>
          )}
          <Pagination page={page} pages={pages} basePath="/search" params={flat} />
        </div>
      </div>
    </div>
  );
}
